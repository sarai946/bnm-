import { useToast, toast } from "@/Ganchos/use-toast";

export { useToast, toast };
